<?php
/**
 * PaymentProcessorException
 *
 * @author Florian Krämer
 * @copyright 2012 Florian Krämer
 * @license MIT
 */
class PaymentProcessorException extends CakeException {
	
}