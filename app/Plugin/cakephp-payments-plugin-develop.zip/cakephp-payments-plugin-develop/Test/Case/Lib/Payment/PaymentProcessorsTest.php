<?php
/**
 * PaymentProcessorsTest
 *
 * @author Florian Kramer
 * @copyright 2012 Florian Kramer
 * @license MIT
 */
class PaymentProcessorsTest extends CakeTest {

}